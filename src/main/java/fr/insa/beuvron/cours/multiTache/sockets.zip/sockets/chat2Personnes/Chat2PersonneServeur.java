/*
Copyright 2000-2014 Francois de Bertrand de Beuvron

This file is part of CoursBeuvron.

CoursBeuvron is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

CoursBeuvron is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with CoursBeuvron.  If not, see <http://www.gnu.org/licenses/>.
 */
package fr.insa.beuvron.cours.multiTache.sockets.chat2Personnes;

import fr.insa.beuvron.cours.m3.gui.TestePanel;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultCaret;

/**
 * chat coté serveur :
 * <pre>
 * Etat 0 : le serveur n'est pas démarré
 * Etat 1 : le serveur est démarré et accepte 1 connection max
 * Etat 2 en cours de conversation
 *
 * table de transition
 *
 * evenement \ etat | 0                         | 1                             | 2                          |
 * -----------------+---------------------------+-------------------------------+----------------------------+
 * bouton start     | demarrage du ServerSocket | impossible car bouton         | impossible car bouton      |
 *   pressé         | bouton start disabled     | normalement disabled          | normalement disabled       |
 *                  | affiche ip +port          |                               |                            |
 *                  | passage etat 1            | ==> erreur                    | ==> erreur                 |
 * -----------------+---------------------------+-------------------------------+----------------------------+
 * connection client| impossible : socket pas   | passage etat 2                | impossible : refusé        |
 *                  | démarré                   |                               | car max une connection     |
 * -----------------+---------------------------+-------------------------------+----------------------------+
 * reçu MESSAGE     | impossible : socket pas   | impossible                    | affiche le message         |
 *                  | démarré                   | ==> envoie ERROR au client    |                            |
 *                  |                           |                               |                            |
 * -----------------+---------------------------+-------------------------------+----------------------------+
 * </pre>
 *
 * @author francois
 */
public class Chat2PersonneServeur extends javax.swing.JPanel {

    public static int TIMEOUTS = 1000;

    private int etat = 0;

    private ThreadServeur leServeur;

    public static void main(String[] args) {
        Chat2PersonneServeur serverPan = new Chat2PersonneServeur();
        TestePanel.pack(serverPan);
    }

    /**
     * Creates new form Chat2PersonneServeur
     */
    public Chat2PersonneServeur() {
        initComponents();

        // pour scroll auto de la JTextArea
        // trouvé sur : http://stackoverflow.com/questions/16621169/scroll-down-automatically-jtextarea-for-show-the-last-lines-added
        DefaultCaret caret = (DefaultCaret) this.jtfMessages.getCaret(); // ←
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        this.retourEtat0();
    }

    private void gereErreur(String message) {
        JOptionPane.showMessageDialog(this, message);
        this.retourEtat0();
    }

    public void afficheMessage(String message) {
        this.jtfMessages.append("In : " + message + "\n");
    }

    private void retourEtat0() {
        System.out.println("retourEtat0");
        this.arreteServeur();
        this.jbStart.setEnabled(true);
        this.jbStop.setEnabled(false);
        this.jtfAdresse.setText("");
        this.jtfPort.setText("");
        this.jtfInput.setEnabled(false);
        this.jtfInput.setText("");
        this.jtfMessages.append("Appuyez sur Start\n");
        this.etat = 0;
    }

    private void etat0Vers1() {
        System.out.println("etat0Vers1");
        ServerSocket sock = this.leServeur.socketServer;
        this.jtfAdresse.setText(sock.getInetAddress().getHostAddress());
        this.jtfPort.setText("" + sock.getLocalPort());
        this.jbStart.setEnabled(false);
        this.jbStop.setEnabled(true);
        this.jtfMessages.append("En attente de connection\n");
        this.etat = 1;
    }

    private void etat1Vers2() {
        System.out.println("etat1Vers2");
        this.jtfInput.setEnabled(true);
        this.jtfMessages.append("Connection établie\n");
        this.etat = 2;
    }

    private void demmarreServeur() {
        this.leServeur = new ThreadServeur();
        this.leServeur.start();
    }

    private void arreteServeur() {
        if (this.leServeur != null) {
            this.leServeur.interrupt();
        }
    }

    private class ThreadServeur extends Thread {

        private ServerSocket socketServer;
        private Socket socketCom;
        private InetAddress local;

        @Override
        public void run() {
            try {
                this.local = InetAddress.getLocalHost();
            } catch (UnknownHostException ex) {
                gereErreur("Erreur : pas d'adresse réseau");
                throw new Error(ex);
            }
            try {
                this.socketServer = new ServerSocket(0, 1, this.local);
            } catch (IOException ex) {
                gereErreur("Erreur : impossible de créer le socket");
                throw new Error(ex);
            }
            try {
                etat0Vers1();
                this.socketServer.setSoTimeout(TIMEOUTS);
                boolean ok = false;
                while (!ok && !this.isInterrupted()) {
                    try {
                        this.socketCom = this.socketServer.accept();
                        this.socketCom.setSoTimeout(TIMEOUTS);
                        ok = true;
                    } catch (InterruptedIOException ex) {
                    }
                }
                if (!ok) {
                    retourEtat0();
                } else {
                    etat1Vers2();
                    try (BufferedReader in = new BufferedReader(
                            new InputStreamReader(
                                    this.socketCom.getInputStream(), Charset.forName("UTF8")))) {
                        while (!this.isInterrupted()) {
                            try {
//                                System.out.println("attends message");
                                String mess = in.readLine();
                                afficheMessage(mess);

                            } catch (SocketTimeoutException ex) {
                            }
                        }
                        retourEtat0();

                    }
                }

            } catch (IOException ex) {
                gereErreur("Erreur : " + ex.getMessage());
            } finally {
                if (this.socketServer != null) {
                    try {
                        this.socketServer.close();
                        if (this.socketCom != null) {
                            this.socketCom.close();
                        }
                    } catch (IOException ex) {
                    }
                }
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jbStart = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jtfAdresse = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jtfPort = new javax.swing.JTextField();
        jbStop = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jtfInput = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtfMessages = new javax.swing.JTextArea();

        jbStart.setText("Start");
        jbStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbStartActionPerformed(evt);
            }
        });

        jLabel1.setText("Adresse : ");

        jtfAdresse.setEditable(false);

        jLabel2.setText("port :");

        jtfPort.setEditable(false);

        jbStop.setText("Stop");
        jbStop.setEnabled(false);
        jbStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbStopActionPerformed(evt);
            }
        });

        jLabel3.setText("message :");

        jtfMessages.setEditable(false);
        jtfMessages.setColumns(20);
        jtfMessages.setRows(5);
        jScrollPane1.setViewportView(jtfMessages);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jbStart, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jbStop, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 61, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jtfAdresse))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfPort))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jtfInput))
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbStart)
                    .addComponent(jbStop))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jtfAdresse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jtfPort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtfInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jbStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbStartActionPerformed
        // TODO add your handling code here:
        if (this.etat != 0) {
            this.gereErreur("Erreur interne : start hors etat 0");
        } else {
            this.demmarreServeur();
        }
    }//GEN-LAST:event_jbStartActionPerformed

    private void jbStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbStopActionPerformed
        // TODO add your handling code here:
        if (this.etat == 0) {
            this.gereErreur("Erreur interne : stop en etat 0");
        } else {
            this.arreteServeur();
        }


    }//GEN-LAST:event_jbStopActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbStart;
    private javax.swing.JButton jbStop;
    private javax.swing.JTextField jtfAdresse;
    private javax.swing.JTextField jtfInput;
    private javax.swing.JTextArea jtfMessages;
    private javax.swing.JTextField jtfPort;
    // End of variables declaration//GEN-END:variables
}
